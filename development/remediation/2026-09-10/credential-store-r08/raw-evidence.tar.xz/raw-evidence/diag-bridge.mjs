// Diagnostic: replicate createWindowsBridge's exact spawn for bridge.ps1 SelfTest
// and capture raw stdout/stderr/exit, which the production reader deliberately hides.
import { spawn } from 'node:child_process'
import { generateKeyPair } from 'node:crypto'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const root = process.env.SystemRoot
const powershellExecutable = join(root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
const directory = 'C:\\Albert\\project\\dsh861\\scripts\\p0-b\\windows-credentials'
const temporary = mkdtempSync(join(tmpdir(), 'dsh861-diag-'))

const { publicKey } = await new Promise((resolve, reject) =>
  generateKeyPair('rsa', { modulusLength: 4096, publicExponent: 65537 }, (e, pub, priv) =>
    e ? reject(e) : resolve({ publicKey: pub })))
const jwk = publicKey.export({ format: 'jwk' })
const requestId = '0123456789abcdef0123456789abcdef'
const request = Buffer.from(JSON.stringify({ version: 1, requestId,
  modulus: Buffer.from(jwk.n, 'base64url').toString('base64'),
  exponent: Buffer.from(jwk.e, 'base64url').toString('base64') }))

const args = ['-NoLogo', '-NoProfile', '-NonInteractive', '-File', join(directory, 'bridge.ps1'), '-Action', 'SelfTest']
const child = spawn(powershellExecutable, args, { cwd: directory, windowsHide: true, shell: false,
  env: { SystemRoot: root, TEMP: temporary, TMP: temporary }, stdio: ['pipe', 'pipe', 'pipe'] })
let out = '', err = ''
child.stdout.on('data', d => { out += d })
child.stderr.on('data', d => { err += d })
child.on('close', (code, signal) => {
  console.log('EXIT=', code, 'SIGNAL=', signal)
  console.log('STDOUT_BYTES=', out.length)
  console.log('STDOUT_HEAD=', JSON.stringify(out.slice(0, 2000)))
  console.log('STDERR=', JSON.stringify(err.slice(0, 4000)))
  rmSync(temporary, { recursive: true, force: true })
})
child.on('error', e => { console.log('SPAWN_ERROR', e); rmSync(temporary, { recursive: true, force: true }) })
child.stdin.end(request)
