if (1 -eq 1 -or 2 -eq 2 -or
3 -eq 3) { "TRAILING-OR-OK" }
