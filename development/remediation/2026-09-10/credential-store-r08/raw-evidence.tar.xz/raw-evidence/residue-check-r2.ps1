# Check exactly the recorded synthetic targets only; never enumerate credentials.
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ExactTargetProbe {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct Credential { public uint Flags; public uint Type; public string TargetName; public string Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten; public uint CredentialBlobSize;
        public IntPtr CredentialBlob; public uint Persist; public uint AttributeCount; public IntPtr Attributes;
        public string TargetAlias; public string UserName; }
    [DllImport("advapi32.dll", EntryPoint = "CredReadW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);
    [DllImport("advapi32.dll", EntryPoint = "CredFree")]
    private static extern void CredFree(IntPtr buffer);
    public static string Check(string target) {
        IntPtr pointer;
        if (CredRead(target, 1, 0, out pointer)) { CredFree(pointer); return "EXISTS"; }
        return Marshal.GetLastWin32Error() == 1168 ? "MISSING" : "ERROR_" + Marshal.GetLastWin32Error();
    }
}
'@
foreach ($target in @(
    'dsh861/selftest/f98059fe48a04245e173b78f6520df36',
    'dsh861/selftest/150cc1b469e91d46c5e708e340fb6ed1',
    'dsh861/selftest/0123456789abcdef0123456789abcdef',
    'dsh861/selftest/0446a76a5a52c9fd67ddc031b488b932')) {
    Write-Output ($target + ' => ' + [ExactTargetProbe]::Check($target))
}

