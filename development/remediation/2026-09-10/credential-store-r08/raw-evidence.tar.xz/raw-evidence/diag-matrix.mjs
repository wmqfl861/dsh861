// Empirical matrix: which spawn shape emits CLIXML module-analysis progress on stderr.
import { spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const powershellExecutable = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
const temporary = mkdtempSync(join(tmpdir(), 'dsh861-diag3-'))
const restricted = { SystemRoot: process.env.SystemRoot, TEMP: temporary, TMP: temporary }
const encode = script => Buffer.from(script, 'utf16le').toString('base64')

function run(label, args, options) {
  const result = spawnSync(powershellExecutable, args,
    { timeout: 50000, windowsHide: true, shell: false, encoding: 'buffer', ...options })
  console.log(label, 'status=', result.status, 'stderrBytes=', result.stderr.length,
    'clixml=', result.stderr.toString().includes('CLIXML'))
  return result
}

// 1: -EncodedCommand trivial, full env, no stdin
run('A encoded-trivial-fullenv', ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
  encode("Write-Output 'ok'")])
// 2: -EncodedCommand trivial, restricted env, stdin piped
run('B encoded-trivial-restricted', ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
  encode("Write-Output 'ok'")], { input: Buffer.alloc(0), env: restricted, cwd: temporary })
// 3: -File trivial, full env
const runner = join(temporary, 'trivial.ps1')
writeFileSync(runner, "Write-Output 'ok'")
run('C file-trivial-fullenv', ['-NoLogo', '-NoProfile', '-NonInteractive', '-File', runner])
// 4: -File trivial, restricted env, stdin piped
run('D file-trivial-restricted', ['-NoLogo', '-NoProfile', '-NonInteractive', '-File', runner],
  { input: Buffer.alloc(0), env: restricted, cwd: temporary })
// 5: -Command trivial, full env
run('E command-trivial-fullenv', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', "Write-Output 'ok'"])
rmSync(temporary, { recursive: true, force: true })
