// Reproduce the SelfTestStore harness with full stderr capture.
import { spawnSync } from 'node:child_process'
import { generateKeyPair, randomBytes } from 'node:crypto'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const directory = 'C:\\Albert\\project\\dsh861\\scripts\\p0-b\\windows-credentials'
const powershellExecutable = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
const temporary = mkdtempSync(join(tmpdir(), 'dsh861-diag2-'))
const restricted = { SystemRoot: process.env.SystemRoot, TEMP: temporary, TMP: temporary }
const { publicKey } = await new Promise((resolve, reject) =>
  generateKeyPair('rsa', { modulusLength: 4096, publicExponent: 65537 }, (e, pub, priv) =>
    e ? reject(e) : resolve({ publicKey: pub })))
const jwk = publicKey.export({ format: 'jwk' })
const requestId = randomBytes(16).toString('hex')
console.log('requestId', requestId)
const script = [
  "$ErrorActionPreference = 'Stop'",
  "[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false, $true)",
  '$request = [Console]::In.ReadToEnd() | ConvertFrom-Json',
  "Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path '" + directory + "' 'native-credential.cs') -Raw -Encoding UTF8) | Out-Null",
  'function New-Secret([string]$Value) {',
  '    $secret = New-Object System.Security.SecureString',
  '    foreach ($character in $Value.ToCharArray()) { $secret.AppendChar($character) }',
  '    $secret.MakeReadOnly()',
  '    $secret',
  '}',
  "$first = New-Secret ('dsh861-synthetic-first-' + $request.requestId)",
  "$second = New-Secret ('dsh861-synthetic-second-' + $request.requestId)",
  '$ciphertext = [Dsh861.Credentials.NativeCredential]::SelfTestStore('
  + '$request.requestId, $first, $second, $second, $request.modulus, $request.exponent)',
  '[Console]::Out.Write($ciphertext)',
].join('\r\n')
const input = Buffer.from(JSON.stringify({ version: 1, requestId,
  modulus: Buffer.from(jwk.n, 'base64url').toString('base64'),
  exponent: Buffer.from(jwk.e, 'base64url').toString('base64') }))
const result = spawnSync(powershellExecutable,
  ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
  { input, timeout: 50000, windowsHide: true, shell: false, encoding: 'buffer', cwd: temporary, env: restricted })
console.log('STATUS', result.status)
console.log('STDOUT_len', result.stdout.length)
console.log('STDERR', JSON.stringify(result.stderr.toString().slice(0, 1500)))
rmSync(temporary, { recursive: true, force: true })
