import {run,evidence,isolatedEnv} from './runner.mjs';
import path from 'node:path';
const env=isolatedEnv();const key=Object.keys(env).find(k=>k.toLowerCase()==='path')??'PATH';env[key]=[evidence+'/tools/node_modules/.bin',path.dirname(process.execPath),env[key]].join(path.delimiter);
const pnpm=evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs';
const pair=await run('57-config-pair-write',process.execPath,[pnpm,'run','verify-translation-pairing','--write','docs/config-catalog.md'],{env});
if(pair.exitCode!==0)process.exit(pair.exitCode??1);
const results=await Promise.all([
 run('58-config-catalog-fresh',process.execPath,[pnpm,'run','verify-config-catalog'],{env}),
 run('59-final-pairs',process.execPath,[pnpm,'run','verify-translation-pairing','docs/config-catalog.md','.agents/notes/implemented/architecture/2026-09-09-p0-b-credential-output-safety.md'],{env}),
 run('60-doc-test-lint',process.execPath,[pnpm,'exec','tsx','scripts/run-oxlint.ts','scripts/project-doc-site.spec.ts'],{env}),
 run('61-final-diff-check','git',['-C','C:/Albert/project/dsh861','diff','--check'],{env})
]);process.exitCode=results.some(r=>r.exitCode!==0)?1:0;
