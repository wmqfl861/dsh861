import {run,evidence,isolatedEnv} from './runner.mjs';
import {mkdirSync,copyFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
const headers=evidence+'/node-headers/26.4.0';
mkdirSync(headers+'/Release',{recursive:true});copyFileSync(evidence+'/node-win-x64.lib',headers+'/Release/node.lib');
writeFileSync(evidence+'/23b-link-layout-diagnosis.json',JSON.stringify({rootCause:'node-gyp --nodedir uses $(Configuration)/node.lib, unlike installed cache x64/node.lib',failure:'23: LNK1104 Release/node.lib absent',repair:'Copy already SHA256-verified exact Node 26.4.0 library to Release/node.lib',repositoryChanged:false},null,2)+'\n');
const env=isolatedEnv();const key=Object.keys(env).find(k=>k.toLowerCase()==='path')??'PATH';env[key]=[evidence+'/tools/node_modules/.bin',path.dirname(process.execPath),env[key]].join(path.delimiter);
Object.assign(env,{npm_config_nodedir:headers,npm_config_store_dir:evidence+'/pnpm-store',npm_config_state_dir:evidence+'/pnpm-state',npm_config_cache_dir:evidence+'/pnpm-cache',npm_config_devdir:evidence+'/node-gyp',XDG_DATA_HOME:evidence+'/data',XDG_STATE_HOME:evidence+'/state'});
const r=await run('23c-pnpm-install-layout-fixed',process.execPath,[evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs','install','--frozen-lockfile','--reporter=append-only'],{env,boundary:'Real frozen workspace install and all required scripts, verified exact Node headers and Release import library'});process.exitCode=r.exitCode??1;
