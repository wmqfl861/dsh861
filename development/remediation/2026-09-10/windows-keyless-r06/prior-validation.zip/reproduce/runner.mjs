import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export const repo = 'C:/Albert/project/dsh861';
export const evidence = 'C:/Albert/project/dsh861-local-validation/20260909-win-keyless-7f42';
export function redact(value) {
  return String(value)
    .replace(/(https?:\/\/)[^\s/@]+:[^\s/@]+@/gi, '$1<REDACTED>@')
    .replace(/((?:authorization|proxy-authorization)\s*[:=]\s*)([^\r\n]+)/gi, '$1<REDACTED>')
    .replace(/\b(?:sk|ghp|gho|github_pat)-?[A-Za-z0-9_-]{20,}\b/g, '<REDACTED>')
    .replace(/((?:api[_-]?key|access[_-]?token|auth[_-]?token|password|secret)\s*[:=]\s*["']?)[^\s,"'\r\n]+/gi, '$1<REDACTED>')
    .replace(/([?&](?:token|key|signature|credential)=)[^&\s]+/gi, '$1<REDACTED>');
}
export function git(args) {
  const result = spawnSync('git', ['-C', repo, ...args], { cwd: repo, encoding: 'utf8', windowsHide: true });
  return { exitCode: result.status, stdout: redact(result.stdout ?? '').trim(), stderr: redact(result.stderr ?? '').trim() };
}
export function digest(file) {
  return existsSync(file) ? createHash('sha256').update(readFileSync(file)).digest('hex') : null;
}
export function snapshot() {
  return {
    head: git(['rev-parse', 'HEAD']), branch: git(['branch', '--show-current']),
    status: git(['status', '--porcelain=v1', '--untracked-files=all']),
    trackedDiffSha256: createHash('sha256').update(git(['diff', 'HEAD', '--binary']).stdout).digest('hex'),
    protectedFiles: Object.fromEntries(['config/agents/models.v1.json','config/agents/models.v1.lock.json','pnpm-lock.yaml'].map(f => [f,digest(path.join(repo,f))]))
  };
}
export function isolatedEnv() {
  const keep = /^(?:PATH|PATHEXT|SYSTEMROOT|WINDIR|COMSPEC|SYSTEMDRIVE|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|PROGRAMFILES(?:\(X86\))?|PROGRAMW6432|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE|OS)$/i;
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => keep.test(key)));
  return { ...env, TEMP: path.join(evidence,'tmp'), TMP: path.join(evidence,'tmp'), TMPDIR: path.join(evidence,'tmp'), npm_config_cache: path.join(evidence,'npm-cache'), npm_config_userconfig: path.join(evidence,'empty.npmrc'), npm_config_globalconfig: path.join(evidence,'empty-global.npmrc'), PNPM_HOME: path.join(evidence,'tools'), XDG_CACHE_HOME: path.join(evidence,'cache'), PNPM_STORE_DIR: path.join(evidence,'pnpm-store'), NO_COLOR: '1', FORCE_COLOR: '0' };
}
export async function run(id, command, args, options={}) {
  mkdirSync(evidence, { recursive:true });
  mkdirSync(path.join(evidence,'tmp'), { recursive:true });
  const metadataPath = path.join(evidence, `${id}.json`);
  if (existsSync(metadataPath)) throw new Error(`Evidence already exists: ${id}`);
  const logPath = path.join(evidence, `${id}.log`);
  const metadata = { id, identity:'ZCode 内置执行子代理', command, args:args.map(redact), cwd:repo, startedAt:new Date().toISOString(), host:{platform:process.platform,release:os.release(),arch:process.arch,node:process.version,nodeExecutable:process.execPath}, before:snapshot(), dependencyBoundary: options.boundary ?? 'Local command; no paid model invocation', logPath };
  writeFileSync(metadataPath, JSON.stringify(metadata,null,2)+'\n');
  const lines=[];
  const child=spawn(command,args,{cwd:repo,env:options.env ?? isolatedEnv(),windowsHide:true,shell:options.shell ?? false,stdio:['ignore','pipe','pipe']});
  for (const [name,stream] of [['stdout',child.stdout],['stderr',child.stderr]]) {
    let pending='';
    stream?.setEncoding('utf8');
    stream?.on('data', chunk=>{ pending+=chunk; const parts=pending.split(/\r?\n|\r/); pending=parts.pop() ?? ''; for(const line of parts){const safe=redact(line);lines.push({stream:name,text:safe});writeFileSync(logPath,lines.map(x=>x.text).join('\n')+'\n');console.log(safe);} });
    stream?.on('end',()=>{if(pending){const safe=redact(pending);lines.push({stream:name,text:safe});console.log(safe);}});
  }
  const result=await new Promise(resolve=>{child.on('error',error=>resolve({exitCode:null,error:redact(error.message)}));child.on('close',(exitCode,signal)=>resolve({exitCode,signal}));});
  metadata.finishedAt=new Date().toISOString(); Object.assign(metadata,result); metadata.after=snapshot();
  metadata.logSha256=createHash('sha256').update(lines.map(x=>x.text).join('\n')+'\n').digest('hex');
  writeFileSync(logPath,lines.map(x=>x.text).join('\n')+'\n');
  metadata.testSummary=lines.map(x=>x.text).filter(x=> /^(?:# (?:tests|pass|fail|cancelled|skipped|todo)|.*(?:Test Files|Tests\s+\d|test suites|tests passed|tests failed))/.test(x));
  writeFileSync(metadataPath, JSON.stringify(metadata,null,2)+'\n');
  console.log(JSON.stringify({id,...result,metadataPath,logPath}));
  return metadata;
}
if (process.argv[1] && path.resolve(process.argv[1])===path.resolve(new URL(import.meta.url).pathname.replace(/^\/(\w:)/,'$1'))) {
  const [, , id, command, ...args]=process.argv;
  const result=await run(id,command,args);
  process.exitCode=result.exitCode ?? 1;
}
