import {run,evidence,repo,isolatedEnv} from './runner.mjs';
import {mkdirSync,mkdtempSync,writeFileSync,readFileSync} from 'node:fs';
import path from 'node:path';
const env=isolatedEnv();
const key=Object.keys(env).find(k=>k.toLowerCase()==='path')??'PATH';env[key]=[evidence+'/tools/node_modules/.bin',path.dirname(process.execPath),env[key]].join(path.delimiter);
const mode=process.argv[2];
if(mode==='regressions') {
 const results=await Promise.all([
  run('38-B-audit-fixed',process.execPath,['--import','tsx/esm','--test','scripts/p0-b/audit-controls.test.mjs'],{env,boundary:'Source path, real tsx, synthetic evidence; timeout negative control previously failed correctly'}),
  run('39-B-security-fixed',process.execPath,['--import','tsx/esm','--test','scripts/p0-b/__tests__/security.test.mjs'],{env,boundary:'Source path, real tsx, synthetic credentials and ordinary Node child; new verdict regression'}),
  run('40-C-codex-fixed',process.execPath,[evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs','exec','vitest','run','packages/subagent/subagent-codex/tests/private-stderr.spec.ts','packages/subagent/subagent-codex/tests/private-stderr-provider.spec.ts','packages/subagent/subagent-codex/tests/subagent-codex.spec.ts'],{env,boundary:'Source Vitest regressions and synthetic Node processes; added host-output sentinel negative control validated'})
 ]);process.exitCode=results.some(r=>r.exitCode!==0)?1:0;
} else if(mode==='loader') {
 const home=mkdtempSync(evidence+'/tmp/loader-built-');Object.assign(env,{DSH_HOME:home+'/.dsh',DSH_AGENTS_HOME:home+'/.agents'});
 for(const dir of [env.DSH_HOME,env.DSH_AGENTS_HOME])mkdirSync(dir,{recursive:true});
 const root=repo+'/packages/subagent/subagent-codex';
 const r=await run('44-loader-built-complete',process.execPath,[root+'/tests/fixtures/loader/driver.ts',root+'/tests/fixtures/loader/codex.patch.yml',root+'/cordis.patch.yml'],{env,boundary:'Existing test-only shipped headless profile Loader composition, current host artifacts under plain Node, dedicated DSH homes; asserts registered services and starts=0'});process.exitCode=r.exitCode??1;
 if(r.exitCode===0){const output=JSON.parse(readFileSync(r.logPath,'utf8'));if(output.starts!==0||output.providers.length!==3||output.tools.length!==3||output.jobTools.length!==3)throw new Error('Loader fixture output mismatch');writeFileSync(evidence+'/41-loader-verdict.json',JSON.stringify({status:'PASS',productStarted:false,output},null,2)+'\n');}
} else if(mode==='lint') {
 const r=await run('42-lint-fixed',process.execPath,[evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs','run','lint:contracts-ready'],{env,boundary:'Whole repository lint using already successful host build; no behavioral package changes requiring rebuild'});process.exitCode=r.exitCode??1;
}
