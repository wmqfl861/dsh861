import {run,evidence,repo,isolatedEnv,digest} from './runner.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
const mode=process.argv[2];
if(mode==='audit-negative') {
  const env={...isolatedEnv(),P0B_AUDIT_RUNNER_MODULE:evidence+'/stalled-runner.mjs'};
  const r=await run(process.argv[3],process.execPath,['--import','tsx/esm','--test','--test-name-pattern','^reject ambiguous/unknown options 1$','scripts/p0-b/audit-controls.test.mjs'],{env,boundary:'Negative control only: explicitly injected synthetic stalled Node runner, expected to reject false success, no product or historical artifact'});process.exitCode=r.exitCode??1;
} else if(mode==='stderr-negative') {
  const file=repo+'/packages/subagent/subagent-codex/tests/private-stderr-provider.fixture.mjs';
  const original=readFileSync(file);
  const changed=original.toString().replace("  const handle = resolved.spawn(command)","  const handle = resolved.spawn(command)\n  spawned.stderr.once('data', chunk => { process.stderr.write(chunk.subarray(0, 28)) })");
  if(changed===original.toString())throw new Error('Negative control insertion not found');
  const before=digest(file);writeFileSync(file,changed);
  try {
    const r=await run('35-stderr-host-sink-negative',process.execPath,[evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs','exec','vitest','run','packages/subagent/subagent-codex/tests/private-stderr-provider.spec.ts'],{boundary:'Negative control temporarily forwards synthetic-only stderr to host; no credentials or native product'});process.exitCode=r.exitCode??1;
  } finally {writeFileSync(file,original);writeFileSync(evidence+'/35-restoration.json',JSON.stringify({file,before,after:digest(file),restored:digest(file)===before},null,2)+'\n');}
}
