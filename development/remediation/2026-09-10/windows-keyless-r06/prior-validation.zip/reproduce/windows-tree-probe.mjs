import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createServer,connect} from 'node:net';
import {fileURLToPath} from 'node:url';
import {appendFileSync} from 'node:fs';
const file=fileURLToPath(import.meta.url);
if(process.argv[2]==='leaf') {
  process.on('exit', code => appendFileSync('C:/Albert/project/dsh861-local-validation/20260909-win-keyless-7f42/tree-leaf-exit.log', JSON.stringify({code})+'\n'));
  const socket=connect(Number(process.argv[3]),'127.0.0.1');
  socket.on('error',()=>process.exit(2));
  socket.on('data',data=>{if(data.toString()==='STOP')socket.end(()=>process.exit(0));else socket.write('PONG');});
  await once(socket,'connect');
  process.stderr.write('SYNTHETIC_TREE_DIAGNOSTIC');
  process.send({ready:true,pid:process.pid});
} else if(process.argv[2]==='wrapper') {
  const leaf=spawn(process.execPath,[file,'leaf',process.argv[3]],{stdio:['ignore','ignore',2,'ipc'],windowsHide:true,env:process.env});
  const [ready]=await once(leaf,'message');
  process.stdout.write(JSON.stringify(ready));
  leaf.disconnect();leaf.unref();
} else {
  const {spawnSubprocess}=await import('file:///C:/Albert/project/dsh861/packages/subprocess/subprocess-local/src/spawn.ts');
  const {withPrivateCodexStderr}=await import('file:///C:/Albert/project/dsh861/packages/subagent/subagent-codex/src/private-stderr.ts');
  const server=createServer();server.listen(0,'127.0.0.1');await once(server,'listening');
  const connected=once(server,'connection');
  let peer;let raw;let leafPid;let report;
  try {
    raw=spawnSubprocess({argv:[process.execPath,file,'wrapper',String(server.address().port)],cwd:'C:/Albert/project/dsh861',stdio:{stdin:'ignore',stdout:'pipe',stderr:'pipe'},graceMs:1000},{spillDir:'C:/Albert/project/dsh861-local-validation/20260909-win-keyless-7f42/tmp'});
    const handle=withPrivateCodexStderr(raw);
    let output='';handle.stdout.on('data',chunk=>{output+=chunk.toString();});
    [peer]=await connected;
    let socketError;
    peer.on('error',error=>{socketError=error.code;});
    const closed=new Promise(resolve=>peer.once('close',resolve));
    const outcome=await handle.done;
    leafPid=JSON.parse(output).pid;
    const beforeAnswer=Promise.race([once(peer,'data').then(([bytes])=>bytes.toString()),closed.then(()=>null)]).catch(()=>null);
    peer.write('PING');
    const beforeReply=await beforeAnswer;
    handle.terminate();
    const waitForExitReported=await handle.waitForExit();
    const answer=Promise.race([once(peer,'data').then(([bytes])=>bytes.toString()),closed.then(()=>null)]).catch(()=>null);
    peer.write('PING');const reply=await answer;
    report={platform:process.platform,node:process.version,ordinaryNodeOnly:true,wrapperOutcome:outcome,beforeReply,waitForExitReported,descendantRespondedAfterTeardown:reply==='PONG',socketError,rawStderrClosed:raw.stderr.closed,remainingDrainListeners:raw.stderr.listenerCount('data'),actualCodexInvoked:false};
    if(!peer.destroyed)peer.write('STOP');await closed;
    if(!raw.stderr.closed)await once(raw.stderr,'close');
    report.cleanup={ownedConnectionClosed:true,rawStderrClosed:raw.stderr.closed,drainListeners:raw.stderr.listenerCount('data')};
    console.log(JSON.stringify(report,null,2));
    assert.equal(report.descendantRespondedAfterTeardown,false,'Windows tree wait reported quiescence while owned descendant still answered IPC');
  } finally {
    if(peer&&!peer.destroyed)peer.end('STOP');
    raw?.terminate();
    server.close();await once(server,'close');
  }
}
