import {run,evidence,isolatedEnv,repo} from './runner.mjs';
import {readFileSync,existsSync} from 'node:fs';
import path from 'node:path';
const group=process.argv[2];
const pnpm=evidence+'/tools/node_modules/pnpm/bin/pnpm.cjs';
const env=isolatedEnv();
const pathKey=Object.keys(env).find(key=>key.toLowerCase()==='path')??'PATH';
env[pathKey]=[evidence+'/tools/node_modules/.bin',path.dirname(process.execPath),env[pathKey]].join(path.delimiter);
Object.assign(env,{npm_config_store_dir:evidence+'/pnpm-store',npm_config_state_dir:evidence+'/pnpm-state',npm_config_cache_dir:evidence+'/pnpm-cache',npm_config_devdir:evidence+'/node-gyp',npm_config_nodedir:evidence+'/node-headers/26.4.0',XDG_DATA_HOME:evidence+'/data',XDG_STATE_HOME:evidence+'/state'});
const installEvidence=evidence+'/23c-pnpm-install-layout-fixed.json';
if(!existsSync(installEvidence)||JSON.parse(readFileSync(installEvidence,'utf8')).exitCode!==0)throw new Error('Dependency installation has not passed');
if(group==='B') {
  const results=await Promise.all([
    run('24-B-audit',process.execPath,['--import','tsx/esm','--test','scripts/p0-b/audit-controls.test.mjs'],{env,boundary:'Real installed tsx and repository source; adapterless foundation; synthetic evidence and owned temporary Git fixture; no real agent'}),
    run('25-B-security',process.execPath,['--import','tsx/esm','--test','scripts/p0-b/__tests__/security.test.mjs'],{env,boundary:'Real installed tsx and repository source; synthetic credentials and ordinary Node subprocess; no real agent or global credentials'}),
  ]);
  process.exitCode=results.some(r=>r.exitCode!==0)?1:0;
} else if(group==='C') {
  const r=await run('26-C-codex',process.execPath,[pnpm,'exec','vitest','run','packages/subagent/subagent-codex/tests/private-stderr.spec.ts','packages/subagent/subagent-codex/tests/private-stderr-provider.spec.ts','packages/subagent/subagent-codex/tests/subagent-codex.spec.ts'],{env,boundary:'Real repository Vitest/source dependencies; mocked app-server protocol and ordinary Node subprocesses; no native Codex task'});
  process.exitCode=r.exitCode??1;
} else if(group==='D-typecheck') {
  const r=await run('27-D-typecheck',process.execPath,[pnpm,'run','typecheck'],{env,boundary:'Full repository declared typecheck including build:lib:host and client tsc; no model invocation'});process.exitCode=r.exitCode??1;
} else if(group==='D-lint') {
  const r=await run('28-D-lint',process.execPath,[pnpm,'run','lint'],{env,boundary:'Full repository declared lint including host build; no model invocation'});process.exitCode=r.exitCode??1;
} else if(group==='D-docs') {
  const r=await run('29-D-docs',process.execPath,[pnpm,'run','test:docs'],{env,boundary:'Repository doc-quick aggregate; offline source checks'});process.exitCode=r.exitCode??1;
}
