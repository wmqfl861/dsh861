import { run, repo, evidence, isolatedEnv, snapshot } from './runner.mjs';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
const group = process.argv[2];
if (group === 'bootstrap') {
  writeFileSync(evidence + '/tools/package.json', JSON.stringify({name:'dsh861-local-validation-tools',private:true})+'\n');
  writeFileSync(evidence + '/09-bootstrap-diagnosis.json', JSON.stringify({identity:'ZCode 内置执行子代理',firstFailure:'08-install-pnpm: EJSONPARSE, exit 1',rootCause:'Temporary tool manifest contained literal /n after JSON from inline Git Bash command normalization',fix:'Regenerate only temporary tool manifest using file script; repository package.json and lockfile unchanged',globalPnpmProbe:'03-pnpm-version stopped after no output; package manifest version 10.33.4, mismatched with required 11.7.0',priorEsmFailure:'Initial inline helper import used bare C: path; corrected to file:///C:/ URL; no repository defect'},null,2)+'\n');
  const r=await run('10-install-pnpm-fixed',process.execPath,['C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','install','--prefix',evidence+'/tools','--no-audit','--no-fund','--fetch-retries=0','pnpm@11.7.0'],{boundary:'Public npm package installation into isolated tools directory; workspace not installed with npm'});
  process.exitCode=r.exitCode ?? 1;
} else if (group === 'A') {
  writeFileSync(evidence+'/11-target-baseline.json',JSON.stringify({at:new Date().toISOString(),...snapshot()},null,2)+'\n');
  const commands=[['12-A-model-check',['scripts/p0-b/model-config.mjs','check']],['13-A-model-tests',['--test','scripts/p0-b/__tests__/model-config.test.mjs']],['14-A-status',['scripts/p0-b/sync-node-status.mjs','--check']]];
  for (const [,args] of commands) for (const arg of args) if (arg.endsWith('.mjs')&&!existsSync(repo+'/'+arg)) throw new Error('Required source absent: '+arg);
  const results=await Promise.all(commands.map(([id,args])=>run(id,process.execPath,args,{boundary:'Repository source and built-in Node modules only; synthetic configuration fixtures; no credentials or native agents'})));
  process.exitCode=results.some(r=>r.exitCode!==0)?1:0;
}
