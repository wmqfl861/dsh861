// Authoring-only harness: TypeScript 5.8.3 supplies a real classic API;
// node:test supplies registration. This is NOT an installed TS6/Vitest run.
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js'
import assert from 'node:assert/strict'
import * as vm from 'node:vm'
import { readFileSync } from 'node:fs'
import * as nodeTests from 'node:test'
const root = '/mnt/data/dsh861-r25-work/'
const baseline = process.argv.includes('--before')
const context = vm.createContext({ process, console })
const compile = file => ts.transpileModule(readFileSync(file,'utf8'), { compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext} }).outputText
const modules = new Map()
function synthetic(id, values) {
  if (!modules.has(id)) modules.set(id, new vm.SyntheticModule(Object.keys(values), function() {
    for (const [k,v] of Object.entries(values)) this.setExport(k,v)
  },{context,identifier:id}))
  return modules.get(id)
}
const sharedFile = baseline ? '/mnt/data/dsh861-r25-evidence/vitest.shared.before.ts' : root+'vitest.shared.ts'
const shared = new vm.SourceTextModule(compile(sharedFile), {context,identifier:'vitest.shared.ts'})
await shared.link(id => {
  assert.equal(id,'@typescript/typescript6','the config must not request the native compiler package as a classic API')
  return synthetic(id,{default:ts})
})
await shared.evaluate()
const spec = new vm.SourceTextModule(compile(root+'scripts/vitest-shared.spec.ts'),{context,identifier:'scripts/vitest-shared.spec.ts'})
await spec.link(id => {
  if(id==='../vitest.shared.ts') return shared
  if(id==='node:assert/strict') return synthetic(id,{default:assert})
  if(id==='node:vm') return synthetic(id,vm)
  if(id==='vitest') return synthetic(id,{it:nodeTests.it})
  throw new Error('unhandled import '+id)
})
await spec.evaluate()
