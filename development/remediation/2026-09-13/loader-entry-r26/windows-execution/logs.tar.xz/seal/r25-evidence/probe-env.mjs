import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire('file:///C:/Albert/project/dsh861/package.json')
const { execa } = require('execa')
const tsx = pathToFileURL(require.resolve('tsx')).href
const driver = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/driver.ts'
const config = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/codex.patch.yml'
const patch = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/cordis.patch.yml'

const baseEnv = {
  DSH_HOME: 'C:/dsh-r25-20260912-01/probe-home/.dsh',
  DSH_AGENTS_HOME: 'C:/dsh-r25-20260912-01/probe-home/.agents',
  TSX_TSCONFIG_PATH: 'C:/Albert/project/dsh861/tsconfig.json',
  PATH: '',
}

for (const [label, extra] of [['bare', {}], ['withSystemRoot', { SystemRoot: process.env.SystemRoot }]]) {
  const t0 = Date.now()
  try {
    const r = await execa(process.execPath, ['--import', tsx, driver, config, patch], {
      cwd: 'C:/dsh-r25-20260912-01/probe-home',
      env: { ...baseEnv, ...extra },
      input: '',
      timeout: 20000,
      killSignal: 'SIGKILL',
      reject: false,
    })
    console.log(label, 'exit', r.exitCode, 'timedOut', r.timedOut, 'ms', Date.now() - t0, 'stdoutLen', r.stdout.length)
  } catch (e) {
    console.log(label, 'THREW', e.message.slice(0, 200), 'ms', Date.now() - t0)
  }
}
