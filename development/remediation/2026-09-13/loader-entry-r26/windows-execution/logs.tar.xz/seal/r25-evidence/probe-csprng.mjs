import { createRequire } from 'node:module'
const { execa } = createRequire('file:///C:/Albert/project/dsh861/package.json')('execa')

const driver = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/driver.ts'
const config = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/codex.patch.yml'
const patch = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/cordis.patch.yml'

const base = {
  DSH_HOME: 'C:/dsh-r25-20260912-01/probe-home/.dsh',
  DSH_AGENTS_HOME: 'C:/dsh-r25-20260912-01/probe-home/.agents',
  TSX_TSCONFIG_PATH: 'C:/Albert/project/dsh861/tsconfig.json',
  PATH: '',
  SystemRoot: 'C:\\WINDOWS',
}

const candidates = {
  windir: { windir: process.env.windir },
  SystemDrive: { SystemDrive: process.env.SystemDrive },
  TEMP: { TEMP: process.env.TEMP, TMP: process.env.TMP },
  ComSpec: { ComSpec: process.env.ComSpec },
  USERPROFILE: { USERPROFILE: process.env.USERPROFILE },
  LOCALAPPDATA: { LOCALAPPDATA: process.env.LOCALAPPDATA, APPDATA: process.env.APPDATA },
  PATHEXT: { PATHEXT: process.env.PATHEXT },
  USERNAME: { USERNAME: process.env.USERNAME },
}

for (const [label, extra] of Object.entries(candidates)) {
  const t0 = Date.now()
  const r = await execa(process.execPath, ['--version'], { cwd: 'C:/dsh-r25-20260912-01/probe-home', extendEnv: false, env: { ...base, ...extra }, reject: false, timeout: 15000 })
  console.log(label.padEnd(13), 'exit', r.exitCode, 'ms', Date.now() - t0, (r.stderr || '').includes('CSPRNG') ? 'CSPRNG_ASSERT' : 'ok', r.stdout.trim().slice(0, 12))
}
console.log('--- minimal (no extra) ---')
{
  const r = await execa(process.execPath, ['--version'], { cwd: 'C:/dsh-r25-20260912-01/probe-home', extendEnv: false, env: base, reject: false, timeout: 15000 })
  console.log('minimal'.padEnd(13), 'exit', r.exitCode, (r.stderr || '').includes('CSPRNG') ? 'CSPRNG_ASSERT' : 'ok', r.stderr.slice(0, 120).replace(/\n/g, ' | '))
}
