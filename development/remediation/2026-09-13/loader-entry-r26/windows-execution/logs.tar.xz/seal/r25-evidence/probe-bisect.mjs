import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
const require = createRequire('file:///C:/Albert/project/dsh861/package.json')
const { execa } = require('execa')

const tsx = pathToFileURL(require.resolve('tsx')).href
const driver = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/driver.ts'
const config = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/tests/fixtures/loader/codex.patch.yml'
const patch = 'C:/Albert/project/dsh861/packages/subagent/subagent-codex/cordis.patch.yml'

const viteVars = {
  TEST: 'true', PROD: '', DEV: '1', SSR: '1', MODE: 'test', BASE_URL: '/',
  FORCE_TTY: '', VITEST: 'true', VITEST_MODE: 'RUN', VITEST_POOL_ID: '1', VITEST_WORKER_ID: '0',
  NODE_ENV: 'test', NPM_CONFIG_USER_AGENT: 'pnpm/12.4.1 npm/? node/? win32 x64',
  PNPM_PACKAGE_NAME: '@deepseek-ai/dsh-root', PNPM_CONFIG_VERIFY_DEPS_BEFORE_RUN: 'false',
}

const groups = {
  none: {},
  viteCore: { TEST: 'true', PROD: '', DEV: '1', SSR: '1', MODE: 'test', BASE_URL: '/' },
  vitestVars: { VITEST: 'true', VITEST_MODE: 'RUN', VITEST_POOL_ID: '1', VITEST_WORKER_ID: '0' },
  nodeEnv: { NODE_ENV: 'test' },
  pnpmVars: { NPM_CONFIG_USER_AGENT: 'x', PNPM_PACKAGE_NAME: 'y', PNPM_CONFIG_VERIFY_DEPS_BEFORE_RUN: 'false' },
  forceTty: { FORCE_TTY: '' },
  all: viteVars,
}

for (const [label, extra] of Object.entries(groups)) {
  const t0 = Date.now()
  try {
    const r = await execa(process.execPath, ['--import', tsx, driver, config, patch], {
      cwd: 'C:/dsh-r25-20260912-01/probe-home',
      env: {
        DSH_HOME: 'C:/dsh-r25-20260912-01/probe-home/.dsh',
        DSH_AGENTS_HOME: 'C:/dsh-r25-20260912-01/probe-home/.agents',
        TSX_TSCONFIG_PATH: 'C:/Albert/project/dsh861/tsconfig.json',
        PATH: '',
        SystemRoot: process.env.SystemRoot,
        NODE_PATH: undefined,
        ...extra,
      },
      input: '', timeout: 25000, killSignal: 'SIGKILL', reject: false,
    })
    console.log(label.padEnd(12), 'exit', r.exitCode, 'timedOut', r.timedOut, 'ms', Date.now() - t0, 'out', r.stdout.length, r.stderr.slice(0, 100).replace(/\n/g, ' | '))
  } catch (e) {
    console.log(label.padEnd(12), 'THREW', e.message.slice(0, 120))
  }
}
