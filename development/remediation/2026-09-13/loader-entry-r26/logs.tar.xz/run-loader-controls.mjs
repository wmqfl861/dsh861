/** Authoring harness: actual two Loader classes, controlled lifecycle imports; not a full Cordis boot. */
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { resolve, dirname, join } from 'node:path'
import test from 'node:test'
import { createContext, SourceTextModule, SyntheticModule } from 'node:vm'
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js'

const base = dirname(new URL(import.meta.url).pathname)
const mode = process.argv[2]
assert.ok(['before', 'after'].includes(mode))
const configRoot = join(base, mode, 'vendor/loader/src/config')
const context = createContext({ console, process, Buffer, setTimeout, clearTimeout, setImmediate })
const modules = new Map()
function synthetic(name, exports) {
  const key = 'synthetic:' + name
  if (!modules.has(key)) modules.set(key, new SyntheticModule(Object.keys(exports), function () {
    for (const [name, value] of Object.entries(exports)) this.setExport(name, value)
  }, { context, identifier: key }))
  return modules.get(key)
}
function source(file) {
  if (modules.has(file)) return modules.get(file)
  const text = readFileSync(file, 'utf8')
  const js = ts.transpileModule(text, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  }, fileName: file }).outputText
  const mod = new SourceTextModule(js, { context, identifier: file })
  modules.set(file, mod)
  return mod
}
async function link(name, parent) {
  if (name === 'node:assert/strict') return synthetic(name, { default: assert })
  if (name === 'vitest') return synthetic(name, { it: test })
  if (name === '@deepseek-ai/cordis') return synthetic(name, {
    Service: { init: Symbol.for('synthetic-service-init') },
    composeError: () => { throw new Error('unexpected lifecycle dependency in focused controls') },
  })
  if (name === '@deepseek-ai/cosmokit') return synthetic(name, {
    isNonNullable: value => value !== null && value !== undefined,
  })
  if (name === './entry.ts') return synthetic(name, {
    Entry: class { constructor() { throw new Error('real plugin activation is outside this authoring harness') } },
  })
  if (name === '../resolve.ts') return synthetic(name, {
    createResolve: () => { throw new Error('module imports are outside this authoring harness') },
  })
  if (name.startsWith('.')) return source(resolve(dirname(parent.identifier), name))
  if (name === '@deepseek-ai/cordis-plugin-loader') return facade
  throw new Error('Unexpected import ' + name)
}
// Re-export the actual classes so the committed test bodies use precisely the same methods.
const facade = new SourceTextModule(`export {EntryGroup} from './group.ts'; export {EntryTree} from './tree.ts'`,
  { context, identifier: join(configRoot, 'facade.ts') })
const spec = source(join(base, 'after/packages/boot/app-boot/tests/loader-entry-transactions.spec.ts'))
await spec.link(link)
await spec.evaluate()
