// Authoring control: exact retrieved Fiber source; reflection/event plumbing and stack diagnostics
// are explicit substitutes. This is not the repository's Context/Loader/Vitest integration run.
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { SourceTextModule, SyntheticModule, createContext } from 'node:vm'
import test from 'node:test'
const require = createRequire(import.meta.url)
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript')
const sourcePath = process.argv[2]
assert.ok(sourcePath)
const source = readFileSync(sourcePath, 'utf8')
const compiled = ts.transpileModule(source, { compilerOptions: { target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext } }).outputText
class DisposableList {
  sn=0; map=new Map(); weak=new WeakMap()
  get length(){return this.map.size}
  push(value){const sn=++this.sn;this.map.set(sn,value);this.weak.set(value,sn);return()=>this.map.delete(sn)}
  delete(value){const sn=this.weak.get(value);if(!sn)return false;return this.map.delete(sn)}
  clear(){const values=[...this.map.values()];this.map.clear();return values.reverse()}
  [Symbol.iterator](){return this.map.values()}
}
const symbols = Object.fromEntries(['effect','intercept','init','initHooks'].map(key=>[key,Symbol.for('cordis.'+key)]))
const context=createContext({console,Promise,Symbol,WeakMap,Map,Error,TypeError,Reflect,Object,Set})
const imports = {
 '@deepseek-ai/cosmokit': {defineProperty:(obj,key,value)=>Object.defineProperty(obj,key,{value,configurable:true}),isNullable:value=>value===undefined||value===null},
 './context.ts':{Context:{intercept:symbols.intercept}},
 './utils.ts':{DisposableList,symbols,isConstructor:func=>Boolean(func.prototype),isObject:value=>value&&(typeof value==='object'||typeof value==='function'),buildOuterStack:()=>()=>[],composeError:fn=>fn({}),getTraceable:(_ctx,value)=>value},
}
const module=new SourceTextModule(compiled,{context,identifier:sourcePath})
await module.link(name=>{
 assert.ok(imports[name],`unexpected import ${name}`)
 const values=imports[name];return new SyntheticModule(Object.keys(values),function(){for(const [k,v] of Object.entries(values))this.setExport(k,v)},{context})
})
await module.evaluate()
const {Fiber,FiberState}=module.namespace
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return{promise,resolve}}
function fixture(execute){
 const errors=[]
 let impl={fiber:{uid:100}}
 const root={
  [symbols.intercept]:Object.create(null),
  extend(meta){return Object.assign(Object.create(this),meta)},
  emit(){},events:{dispatch:()=>[]},logger:{error:error=>errors.push(error)},
  registry:{counter:1,has:()=>true,delete(){}},
  reflect:{store:{},_getImpl:()=>impl,notify(){}},
  waterfall(...args){return args.at(-1)()},
  effect(...args){return this.fiber.effect(...args)},
 }
 root.fiber=new Fiber(root,{}, {},null,()=>[])
 const runtime={callback:execute,fibers:new DisposableList(),name:'control'}
 const fiber=new Fiber(root,{}, {dependency:null},runtime,()=>[])
 return {fiber,errors,root,notify(){fiber._checkImpl('dependency');fiber._refresh()},setImpl(value){impl=value},async close(){await fiber.dispose();await root.fiber.dispose()}}
}
test('repeated ready notifications preserve a failed activation and do not rerun its effects',async()=>{
 let starts=0,cleanups=0
 const failure=new Error('startup failed')
 const f=fixture(async ctx=>{starts++;ctx.effect(()=>()=>{cleanups++});throw failure})
 try {
  await assert.rejects(f.fiber.await(),e=>e===failure)
  f.notify()
  await assert.rejects(f.fiber.await(),e=>e===failure)
  assert.equal(starts,1);assert.equal(cleanups,1)
 }finally{await f.close()}
})
test('ready notification during awaited rollback cannot schedule another activation',async()=>{
 let starts=0
 const entered=deferred(),release=deferred(),failure=new Error('startup failed')
 const f=fixture(async ctx=>{starts++;ctx.effect(()=>async()=>{entered.resolve();await release.promise});throw failure})
 try{
  await entered.promise
  assert.equal(f.fiber.state,FiberState.UNLOADING)
  f.notify();release.resolve()
  await assert.rejects(f.fiber.await(),e=>e===failure)
  assert.equal(starts,1)
 }finally{release.resolve();await f.close()}
})
test('a genuinely absent dependency may recover with the same owner after failure',async()=>{
 let starts=0;const failure=new Error('first only')
 const f=fixture(async()=>{if(++starts===1)throw failure})
 try{
  await assert.rejects(f.fiber.await(),e=>e===failure)
  f.setImpl(undefined);f.notify()
  f.setImpl({fiber:{uid:100}});f.notify()
  await f.fiber.await();assert.equal(starts,2);assert.equal(f.fiber.state,FiberState.ACTIVE)
 }finally{await f.close()}
})
test('a new dependency owner can retry a failed activation',async()=>{
 let starts=0;const failure=new Error('first only')
 const f=fixture(async()=>{if(++starts===1)throw failure})
 try{
  await assert.rejects(f.fiber.await(),e=>e===failure)
  f.setImpl({fiber:{uid:101}});f.notify()
  await f.fiber.await();assert.equal(starts,2)
 }finally{await f.close()}
})
test('explicit update retries a failed activation with unchanged dependencies',async()=>{
 let starts=0;const failure=new Error('first only')
 const f=fixture(async()=>{if(++starts===1)throw failure})
 try{
  await assert.rejects(f.fiber.await(),e=>e===failure)
  await f.fiber.update({retry:true});await f.fiber.await();assert.equal(starts,2)
 }finally{await f.close()}
})
test('disposal followed by dependency recovery cannot revive a failed fiber',async()=>{
 let starts=0;const failure=new Error('always')
 const f=fixture(async()=>{starts++;throw failure})
 await assert.rejects(f.fiber.await(),e=>e===failure)
 await f.close();f.setImpl(undefined);f.notify();f.setImpl({fiber:{uid:101}});f.notify()
 await Promise.resolve();assert.equal(starts,1);assert.equal(f.fiber.uid,null)
})
test('a dependency that disappears during awaited startup can recover afterward',async()=>{
 let starts=0;const entered=deferred(),release=deferred(),failure=new Error('first only')
 const f=fixture(async()=>{if(++starts===1){entered.resolve();await release.promise;throw failure}})
 try{
  await entered.promise;f.setImpl(undefined);f.notify();release.resolve()
  await assert.rejects(f.fiber.await(),e=>e===failure)
  f.setImpl({fiber:{uid:100}});f.notify();await f.fiber.await();assert.equal(starts,2)
 }finally{release.resolve();await f.close()}
})
test('a failing recovery latches its new dependency identity too',async()=>{
 let starts=0;const failure=new Error('always')
 const f=fixture(async()=>{starts++;throw failure})
 try{
  await assert.rejects(f.fiber.await(),e=>e===failure)
  f.setImpl({fiber:{uid:101}});f.notify();await assert.rejects(f.fiber.await(),e=>e===failure)
  f.notify();await assert.rejects(f.fiber.await(),e=>e===failure)
  assert.equal(starts,2)
 }finally{await f.close()}
})
