const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root = '/mnt/data/dsh861_r26_work/after';
const code = ['vendor/cordis/src/fiber.ts','packages/host/directory-picker-auto/tests/failure-recovery.spec.ts'];
for (const file of code) {
 const parsed=ts.createSourceFile(file,fs.readFileSync(path.join(root,file),'utf8'),ts.ScriptTarget.Latest,true);
 if(parsed.parseDiagnostics.length)throw new Error(`parse failure: ${file}`);
}
const docs=['vendor/README.md','.agents/notes/implemented/architecture/2026-09-13-failed-fiber-recovery.md','.agents/notes/implemented/architecture/2026-09-13-failed-fiber-recovery.zh.md','development/handoffs/WINDOWS_KEYLESS_INTEGRATION.2026-09-10.md'];
for(const file of [...code,...docs]){
 const text=fs.readFileSync(path.join(root,file),'utf8');
 if(!text.endsWith('\n')||text.endsWith('\n\n')||text.split('\n').some(line=>/[ \t]+$/.test(line)))throw new Error(`whitespace failure: ${file}`);
 if(docs.includes(file) && text.split('\n').filter(line=>line.startsWith('```')).length%2)throw new Error('fence mismatch');
 if(/sk-[A-Za-z0-9]{24,}/.test(text))throw new Error('credential-shaped text');
}
const en=fs.readFileSync(path.join(root,docs[1]),'utf8'),zh=fs.readFileSync(path.join(root,docs[2]),'utf8');
if(JSON.stringify(en.match(/^## .+$/gm))!==JSON.stringify(zh.match(/^## .+$/gm)))throw new Error('note structure mismatch');
console.log(JSON.stringify({kind:'syntax-and-document-structure-only',typescriptAPI:ts.version,parsedTypeScriptFiles:code,bilingualNotePairs:1,whitespaceAndFences:'PASS',credentialPatternScan:'PASS',strictTypecheck:'NOT_RUN',repositoryGenerators:'NOT_RUN'},null,2));
